<!DOCTYPE HTML>
<!--
	Intensify by TEMPLATED
	templated.co @templatedco
	Released for free under the Creative Commons Attribution 3.0 license (templated.co/license)
-->
<html>
	<head>
		<title>Usuarios</title>
		<meta charset="utf-8" />
		<meta name="viewport" content="width=device-width, initial-scale=1" />
		<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
		<link rel="stylesheet" href="http://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.2.0/css/font-awesome.min.css">
  		<link rel="stylesheet" href="assets/css/main.css" />
		<link rel="stylesheet" href="assets/css/main2.css" />
	</head>
	<body class="subpage">

		<!-- Header -->
			<header id="header">
				<nav class="left">
					<a href="#menu"><span>Menu</span></a>
				</nav>
				<a href="index.php" class="logo">Vet Co</a>
				<nav class="right">
					<a href="login.html" class="button alt" id="iniciar_ses">Iniciar sesión</a>
					<?php
						session_start();
						if (isset($_SESSION['loggedin']) && $_SESSION['loggedin'] == true) {
							echo "<script>document.getElementById('iniciar_ses').style.visibility = 'hidden';</script>";

							echo "<a href='salir.php' class='button alt'>Cerrar sesión</a>";
							//echo "<script></script>"
						}else{
							echo "<script>document.getElementById('iniciar_ses').style.visibility = 'visible';</script>";
						}
					?>
				</nav>
			</header>

		<!-- Menu -->
		<nav id="menu">
				<ul class="links" id="opciones">
					<li><a href="index.php">Inicio</a></li>
					<li><a href="usuarios.php">Usuarios</a></li>
					<li><a href="proveedores.php">Proveedores</a></li>
					<?php
						if (isset($_SESSION['loggedin']) && $_SESSION['loggedin'] == true) {
							if($_SESSION["tipo"]==0){
								//echo "<li><a href='proveedores.php'>Proveedores</a></li>";
			

								echo "<script>
									$(document).ready(function(){
										$('#opciones').append('<li><a href=\'usuarios.php\'>usuario</a></li>'); 
									});
								</script>";
								
							}
						}
					?>
				</ul>
				<ul class="actions vertical">
					<li><a href="login.php" class="button fit">Iniciar sesión</a></li>
				</ul>
			</nav>

		<!-- Main -->
			<section id="main" class="wrapper">
				<?php
			if (isset($_SESSION['loggedin']) && $_SESSION['loggedin'] == true) {
						if($_SESSION['tipo']==0){

							echo "<h1>hola: ".$_SESSION['username']."<br></h1>";

							$day = "";	
							$contra = "";
				try{
    					$conn = new PDO('mysql:host=localhost;dbname=vetingweb1', "root", $contra);
					    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    					$sql = $conn->prepare('SELECT * FROM agenda WHERE correo = :Dia');
					    $sql->execute(array('Dia' => $day));
    					$resultado = $sql->fetchAll();
    					foreach ($resultado as $row) {
        				echo $row["id"];
    				}
	$correo = $_SESSION['username'];
    $consulta = "SELECT * FROM agenda WHERE correo = '$correo'";
    //$consulta1 = "INSERT INTO citas(diacita,horacita,asuntocita) Values ($day,$hora,$asunto)";
    //$conn->exec($consulta1);

	$res = $conn->query($consulta);
	?> 
	<div id= "div2">
		<table>

            <th>id</th>
          	 <th>Hora</th>
           	<th>Dia</th>
           	<th>asunto</th>

		</table>

		<div id ="div1">

			<table border="1"> 

	
			<?php
    		while($data = $res->fetch()) {?> 
				<tr>
				<td WIDTH="10" 
				HEIGHT="50%"> <?php echo $data['id'] ?> </td>
				<td WIDTH="10" 
				HEIGHT="50%"> <?php echo ($data['hora']) ?> </td>
				<td WIDTH="10" 
				HEIGHT="50%"> <?php echo ($data['dia']) ?> </td>
				<td WIDTH="10" 
				HEIGHT="50%"> <?php echo ($data['asunto']) ?> </td>
			
			<?php }	
			?> </table>
		</div>

	</div>

<br>
<br>
<br>

<div >
	<form action="add.php" method="post">
		   


		   fecha de la cita
		   <input type="Date" name= fecha required/>
		   
		   


		   <label for="appt">elige la hora de la cita:</label>

		   <input id="appt" type="time" id="appt" name="appt"
			min="12:00" max="18:00" required
			pattern="[0-9]{2}:[0-9]{2}">
			<span class="validity"></span>

			<?php
$day = "";	
$contra = "";
    					$conn2 = new PDO('mysql:host=localhost;dbname=vetingweb1', "root", $contra);
					    $conn2->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    					$sql2 = $conn2->prepare('SELECT * FROM proveedores ');
					    $sql2->execute(array('' => $day));
    					$resultado2 = $sql2->fetchAll();

    $consulta2 = "SELECT * FROM proveedores";
    //$consulta1 = "INSERT INTO citas(diacita,horacita,asuntocita) Values ($day,$hora,$asunto)";
    //$conn->exec($consulta1);

    $res2 = $conn2->query($consulta2);

$inc = 1
?>
			<select name="asunto" required>
		   <option value="">seleccione: </option>
		   <?php $res2 = $conn2->query($consulta2);
		   while($data2 = $res2->fetch()) {
		
			echo '<option value="'.$data2[servicio].'">'.$data2[servicio].'</option>';
			$inc = $inc+1;
			}
		   ?>
		   </select>



		   <!--Asunto<input type="text" name="asunto" required/>-->
		   <input type="submit" name = "guardar" value="Guardar" require/>
		   <input type="submit" name = "borrar" value="actualizar" require/>
		   <input type="hidden" name="correo" value="<?php echo $_SESSION['username'];?>"/>
		   </form>



		   


	   <form action="borrar.php" method="post">
	   id<input type="text" name="id" size="30%" placeholder ="ingrese id a borrar " required/>
	   <input type="submit" value="Borrar"  />
	   </form>
		</div>


		<form>
  <p class="clasificacion">
    <input id="radio1" type="radio2" name="estrellas" value="5"><!--
    --><label for="radio1">★</label><!--
    --><input id="radio2" type="radio2" name="estrellas" value="4"><!--
    --><label for="radio2">★</label><!--
    --><input id="radio3" type="radio2" name="estrellas" value="3"><!--
    --><label for="radio3">★</label><!--
    --><input id="radio4" type="radio2" name="estrellas" value="2"><!--
    --><label for="radio4">★</label><!--
    --><input id="radio5" type="radio2" name="estrellas" value="1"><!--
    --><label for="radio5">★</label>
  </p>
</form>







<div class="container">
    <h3>Starrr</h3>

    <h5>Click to rate:</h5>
    <div class='starrr' id='star2'></div>
    <div>&nbsp;
      <span class='your-choice-was' style='display: none;'>
        Your rating was <span class='choice'></span>.
      </span>
    </div>


  <script src="http://cdnjs.cloudflare.com/ajax/libs/jquery/1.11.1/jquery.js"></script>
  <script src="dist/starrr.js"></script>
  <script>
    $('#star').starrr({
      change: function(e, value){
        if (value) {
          $('.your-choice-was').show();
          $('.choice').text(value);
        } else {
          $('.your-choice-was').hide();
        }
      }
    });

  </script>


		<?php
							}catch(PDOException $e){
								echo "ERROR: " . $e->getMessage();
							}
							echo "<script>
								$(document).ready(function(){
									$('#footer').before('<p></p>'); 
								});


								
							</script>";
						}
					}else{



				echo"<div class='inner'>"
					."<header class='align-center'>"
						."<h1>Usuarios</h1>"
						."<p>Conoce los servicios que proporcionamos a nuestros usuarios</p>"
                    ."</header>"

                    ."<div class='image fit'>"
                            ."<img src='images/petown.jpg' alt='' />"
                    ."</div>"
                    
                    ."<div class='6u 12u$(small)'>"

                            ."<h3>Servicios</h3>"
                            ."<ul>"
                                ."<h4><li>Agende sus citas con veterinarios de su elección</li></h4>"
                                ."<h4><li>Registre su estadía</li></h4>"
                                ."<h4><li>Cancele o pospongo sus citas</li></h4>"
                                ."<h4><li>Gran variedad de veterinarios</li></h4>"
                            ."</ul>"
                    ."</div>"
                    
					."<div class='align-center'>"
						."<h4>Regístrate como usuario para disfrutar de los servicios</h4>"
					."</div>"
				."</div> ";
				}
			?>
		</section>
						
		<!-- Footer -->
		<footer id="footer">
				<div class="inner">
					<h2>Contáctanos</h2>
					<ul class="actions">
						<li><span class="icon fa-phone"></span> <a href="#">(221) 1295260</a></li>
						<li><span class="icon fa-envelope"></span> <a href="#">vetco_contact@vetco.com</a></li>
						<li><span class="icon fa-map-marker"></span> 14 Sur, Av San Claudio, Cd Universitaria. Puebla, Pue.</li>
					</ul>
				</div>
			</footer>

		<!-- Scripts -->
			<script src="assets/js/jquery.min.js"></script>
			<script src="assets/js/jquery.scrolly.min.js"></script>
			<script src="assets/js/skel.min.js"></script>
			<script src="assets/js/util.js"></script>
			<script src="assets/js/main.js"></script>
			
	</body>

</html>