
<!DOCTYPE HTML>
<!--
	Intensify by TEMPLATED
	templated.co @templatedco
	Released for free under the Creative Commons Attribution 3.0 license (templated.co/license)
-->
<html>
	<head>
		<title>Proveedores</title>
		<meta charset="utf-8" />
		<meta name="viewport" content="width=device-width, initial-scale=1" />
		<script src="https://code.jquery.com/jquery-1.12.4.min.js"></script>
		<link rel="stylesheet" href="assets/css/main.css" />
	</head>
	<body class="subpage">

		<!-- Header -->
			<header id="header">
				<nav class="left">
					<a href="#menu"><span>Menu</span></a>
				</nav>
				<a href="index.php" class="logo">Vet Co</a>
				<nav class="right">
					<a href="login.html" class="button alt" id="iniciar_ses">Iniciar sesión</a>
					<?php
						session_start();
						if (isset($_SESSION['loggedin']) && $_SESSION['loggedin'] == true) {
							echo "<script>document.getElementById('iniciar_ses').style.visibility = 'hidden';</script>";

							echo "<a href='salir.php' class='button alt'>Cerrar sesión</a>";
							//echo "<script></script>"
						}else{
							echo "<script>document.getElementById('iniciar_ses').style.visibility = 'visible';</script>";
						}
					?>
				</nav>
			</header>

		<!-- Menu -->
        <nav id="menu">
				<ul class="links" id="opciones">
					<li><a href="index.php">Inicio</a></li>
					<li><a href="usuarios.php">Usuarios</a></li>
					<li><a href="proveedores.php">Proveedores</a></li>
					<?php
						if (isset($_SESSION['loggedin']) && $_SESSION['loggedin'] == true) {
							if($_SESSION["tipo"]==2){
								//echo "<li><a href='proveedores.php'>Proveedores</a></li>";
								echo "<script type='text/javascript'>
									$(document).ready(function(){
										$('#opciones').append('<li><a href=\'administrator.php\'>Administrador</a></li>'); 
									});
								</script>";
							}
						}
					?>
				</ul>
				<ul class="actions vertical">
					<li><a href="login.html" class="button fit">Iniciar sesión</a></li>
				</ul>
			</nav>

		<!-- Main -->
			<section id="main" class="wrapper">
				<?php
					//session_start();
					if (isset($_SESSION['loggedin']) && $_SESSION['loggedin'] == true) {
						if($_SESSION['tipo']==1){

							echo "hola: ".$_SESSION['username']."<br>";
							$day = "";
							$contra = "";
							try{
								$conn = new PDO('mysql:host=localhost;dbname=vetingweb1', "root", $contra);
								$conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
								$sql = $conn->prepare('SELECT * FROM proveedores WHERE correo = :Correo');
								$sql->execute(array('Correo' => $day));
								$resultado = $sql->fetchAll();
								foreach ($resultado as $row) {
									echo $row["correo"];
								}
								$correo = $_SESSION['username'];
								$consulta = "SELECT * FROM proveedores WHERE correo = '$correo'";
								//$consulta1 = "INSERT INTO citas(diacita,horacita,asuntocita) Values ($day,$hora,$asunto)";
								//$conn->exec($consulta1);
							
								$res = $conn->query($consulta);
								?> 
								<div id= "div2">
									<table>
							
										<th>horario</th>
										   <th>servicio</th>

							
									</table>
							
									<div id ="div1">
							
										<table border="1"> 
							
								
										<?php
										while($data = $res->fetch()) {?> 
											<tr>
											<td WIDTH="10" 
											HEIGHT="50%"> <?php echo $data['servicio'] ?> </td>
											<td WIDTH="10" 
											HEIGHT="50%"> <?php echo ($data['horario']) ?> </td>
											
										
										<?php }	
										?> </table>
									</div>
							
								</div>
								<br>
<br>
<br>


	   <form action="addagenda.php" method="post">
			<!--<p>s1<input type="text" name="solicitud_atendida" default/></p> -->
			<label for="appt">elige la hora del servicio:</label>

<input id="appt" type="time" id="appt" name="horario"
 min="12:00" max="18:00" required
 pattern="[0-9]{2}:[0-9]{2}">
			<input type="hidden" name="correo" value="<?php echo $_SESSION['username'];?>"/>
			<p>servicio<input type="text" name ="servicio" required/></p>
            <p><input type="submit" value="Guardar" require/></p>
        </form>
		<?php
							}catch(PDOException $e){
								echo "ERROR: " . $e->getMessage();
							}
							echo "<script>
								$(document).ready(function(){
									$('#footer').before('<p>Hola, proveedor</p>'); 
								});


								
							</script>";
						}else{
							echo "<div class='inner'>".
						"<header class='align-center'>"
							."<h1>Proveedores</h1>"
							."<p>Únete a la plataforma y ofrece tus servicios como veterinario</p>"
						."</header>"
	
						."<div class='image fit'>"
								."<img src='images/veter.jpg' alt='' />"
						."</div>"
						
						."<div class='6u 12u$(small)'>"
								."<h3>Ventajas</h3>"
								."<ul>"
									."<h4><li>Crea tu perfil</li></h4>"
									."<h4><li>Muestra los servicios que ofreces</li></h4>"
									."<h4><li>Obten una puntuación de los usuarios que usen tus servicios</li></h4>"
								."</ul>"
						."</div>"
	
						."<div class='align-center'>"  
								."<h4>Regístrate como proveedor para comenzar a proporcionar tus servicios</h4>"
						."</div>"
					
					."</div>";
					
						}
					}else{
						//echo "No estás logueado";
						echo "<div class='inner'>".
						"<header class='align-center'>"
							."<h1>Proveedores</h1>"
							."<p>Únete a la plataforma y ofrece tus servicios como veterinario</p>"
						."</header>"
	
						."<div class='image fit'>"
								."<img src='images/veter.jpg' alt='' />"
						."</div>"
						
						."<div class='6u 12u$(small)'>"
								."<h3>Ventajas</h3>"
								."<ul>"
									."<h4><li>Crea tu perfil</li></h4>"
									."<h4><li>Muestra los servicios que ofreces</li></h4>"
									."<h4><li>Obten una puntuación de los usuarios que usen tus servicios</li></h4>"
								."</ul>"
						."</div>"
	
						."<div class='align-center'>"  
								."<h4>Regístrate como proveedor para comenzar a proporcionar tus servicios</h4>"
						."</div>"
					
					."</div>";
					}
				?>
			</section>

		<!-- Footer -->
		<footer id="footer">
				<div class="inner">
					<h2>Contáctanos</h2>
					<ul class="actions">
						<li><span class="icon fa-phone"></span> <a href="#">(221) 1295260</a></li>
						<li><span class="icon fa-envelope"></span> <a href="#">vetco_contact@vetco.com</a></li>
						<li><span class="icon fa-map-marker"></span> 14 Sur, Av San Claudio, Cd Universitaria. Puebla, Pue.</li>
					</ul>
				</div>
			</footer>

		<!-- Scripts -->
			<script src="assets/js/jquery.min.js"></script>
			<script src="assets/js/jquery.scrolly.min.js"></script>
			<script src="assets/js/skel.min.js"></script>
			<script src="assets/js/util.js"></script>
			<script src="assets/js/main.js"></script>

	</body>
</html>