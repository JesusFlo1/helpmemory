<html>
    <head>
        <title>Panel de administrador</title>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>
        <link rel="stylesheet" href="assets/css/main.css" />
    </head>

    <body>

        <!-- Header -->
			<header id="header">
                    <nav class="left">
                        <a href="#menu"><span>Menu</span></a>
                    </nav>
                    <a href="index.php" class="logo">Vet Co</a>
                    <nav class="right">
                        <a href="login.html" class="button alt" id="iniciar_ses">Iniciar sesión</a>
                        <?php
                            session_start();
                            if (isset($_SESSION['loggedin']) && $_SESSION['loggedin'] == true) {
                                echo "<script>document.getElementById('iniciar_ses').style.visibility = 'hidden';</script>";
    
                                echo "<a href='salir.php' class='button alt'>Cerrar sesión</a>";
                                //echo "<script></script>"
                            }else{
                                echo "<script>document.getElementById('iniciar_ses').style.visibility = 'visible';</script>";
                            }
                        ?>
                    </nav>
                </header>


                <!-- Menu -->
			<nav id="menu">
				<ul class="links" id="opciones">
					<li><a href="index.php">Inicio</a></li>
					<li><a href="usuarios.php">Usuarios</a></li>
					<li><a href="proveedores.php">Proveedores</a></li>
					<?php
						if (isset($_SESSION['loggedin']) && $_SESSION['loggedin'] == true) {
							if($_SESSION['tipo']==2){
								//echo "<li><a href='proveedores.php'>Proveedores</a></li>";
								echo "<script>
									$(document).ready(function(){
										$('#opciones').append('<li><a href=\'administrator.php\'>Administrador</a></li>'); 
									});
								</script>";
							}
						}
					?>
				</ul>
				<ul class="actions vertical">
					<li><a href="login.html" class="button fit">Iniciar sesión</a></li>
				</ul>
			</nav>

        <div class="container text-center">
            <div class="form-group">
                <a href="#" class="btn btn-primary btn-lg" role="button">Generar reportes</a>
            </div>
            <div class="form-group">
                <a href="solicitudes.php" class="btn btn-primary btn-lg" role="button">Administrar solicitudes</a>
            </div>            
        </div>
    </body>
</html>