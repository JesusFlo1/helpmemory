<!DOCTYPE HTML>
<!--
	Intensify by TEMPLATED
	templated.co @templatedco
	Released for free under the Creative Commons Attribution 3.0 license (templated.co/license)
-->
<html>
	<head>
		<title>Vet Co</title>
		<meta charset="utf-8" />
		<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
		<meta name="viewport" content="width=device-width, initial-scale=1" />
		<link rel="stylesheet" href="assets/css/main.css" />
	</head>
	<body>

		<!-- Header -->
			<header id="header">
				<nav class="left">
					<a href="#menu"><span>Menu</span></a>
				</nav>
				<a href="index.php" class="logo">Vet Co</a>
				<nav class="right">
					<a href="login.html" class="button alt" id="iniciar_ses">Iniciar sesión</a>
					<?php
						session_start();
						if (isset($_SESSION['loggedin']) && $_SESSION['loggedin'] == true) {
							echo "<script>document.getElementById('iniciar_ses').style.visibility = 'hidden';</script>";

							echo "<a href='salir.php' class='button alt'>Cerrar sesión</a>";
							//echo "<script></script>"
						}else{
							echo "<script>document.getElementById('iniciar_ses').style.visibility = 'visible';</script>";
						}
					?>
				</nav>
				
			</header>

		<!-- Menu -->
			<nav id="menu">
				<ul class="links" id="opciones">
					<li><a href="index.php">Inicio</a></li>
					<li><a href="usuarios.php">Usuarios</a></li>
					<li><a href="proveedores.php">Proveedores</a></li>
					<?php
						if (isset($_SESSION['loggedin']) && $_SESSION['loggedin'] == true) {
							if($_SESSION['tipo']==2){
								//echo "<li><a href='proveedores.php'>Proveedores</a></li>";
								echo "<script>
									$(document).ready(function(){
										$('#opciones').append('<li><a href=\'administrator.php\'>Administrador</a></li>'); 
									});
								</script>";
							}
						}
					?>
				</ul>
				<ul class="actions vertical">
					<li><a href="login.html" class="button fit">Iniciar sesión</a></li>
				</ul>
			</nav>

		<!-- Banner -->
			<section id="banner">
				<div class="content">
					<h1>La mejor elección para tus mascotas</h1>
					<p>Conoce los servicios que proporcionamos</p>
					<ul class="actions">
						<li><a href="#one" class="button scrolly">Empezar</a></li>
					</ul>
				</div>
			</section>

		<!-- One -->
			<section id="one" class="wrapper">
				<div class="inner flex flex-3">
					<div class="flex-item left">
						<div>
							<h3>Proporcionamos servicios para tus mascotas</h3>
							<p>Pregunta por servicios especiales con nuestro equipo de veterinarios</p>
						</div>
						<div>
							<h3>Únete al equipo</h3>
							<p>Regístrate como proveedor para proporcionar tus servicios como veterinario</p>
						</div>
					</div>
					<div class="flex-item image fit round">
						<img src="images/images.jpg" alt="" />
					</div>
					<div class="flex-item right">
						<div>
							<h3>La salud de tu mascota al alcance de tu mano </h3>
							<p>Agenda citas con los distintos especialistas con los que contamos</p>
						</div>
						<div>
							<h3>Conoce la valoración de cada veterinario</h3>
							<p>Gracias a la retroalimentación de la comunidad, puedes conocer la valoración de cada veterinario</p>
						</div>
					</div>
				</div>
			</section>

		<!-- Two -->
			<section id="two" class="wrapper style1 special">
				<div class="inner">
					<h2>Comprometidos con un tratamiento ético</h2>
					<figure>
					    <blockquote>
					        " Los animales no son propiedades o cosas, sino organismos vivientes, sujetos de una vida, que merecen nuestra compasión, respeto, amistad y apoyo"
					    </blockquote>
					    <footer>
					        <cite class="author">Marc Bekoff</cite>
					        <cite class="company">Cofundador de Etólogos para el tratamiento ético de los animales.</cite>
					    </footer>
					</figure>
				</div>
			</section>
		<!--
		
			<section id="three" class="wrapper">
				<div class="inner flex flex-3">
					<div class="flex-item box">
						<div class="image fit">
							<img src="images/pic02.jpg" alt="" />
						</div>
						<div class="content">
							<h3>Consequat</h3>
							<p>Placerat ornare. Pellentesque od sed euismod in, pharetra ltricies edarcu cas consequat.</p>
						</div>
					</div>
					<div class="flex-item box">
						<div class="image fit">
							<img src="images/pic03.jpg" alt="" />
						</div>
						<div class="content">
							<h3>Adipiscing</h3>
							<p>Morbi in sem quis dui placerat Pellentesque odio nisi, euismod pharetra lorem ipsum.</p>
						</div>
					</div>
					<div class="flex-item box">
						<div class="image fit">
							<img src="images/pic04.jpg" alt="" />
						</div>
						<div class="content">
							<h3>Malesuada</h3>
							<p>Nam dui mi, tincidunt quis, accu an porttitor, facilisis luctus que metus vulputate sem magna.</p>
						</div>
					</div>
				</div>
			</section>
		-->
		<!-- Footer -->
			<footer id="footer">
				<div class="inner">
					<h2>Contáctanos</h2>
					<ul class="actions">
						<li><span class="icon fa-phone"></span> <a href="#">(221) 1295260</a></li>
						<li><span class="icon fa-envelope"></span> <a href="#">vetco_contact@vetco.com</a></li>
						<li><span class="icon fa-map-marker"></span> 14 Sur, Av San Claudio, Cd Universitaria. Puebla, Pue.</li>
					</ul>
				</div>
			</footer>

		<!-- Scripts -->
			<script src="assets/js/jquery.min.js"></script>
			<script src="assets/js/jquery.scrolly.min.js"></script>
			<script src="assets/js/skel.min.js"></script>
			<script src="assets/js/util.js"></script>
			<script src="assets/js/main.js"></script>

	</body>
</html>