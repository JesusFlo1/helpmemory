<?php
    session_start();
    try{
        $usuario = "root";
        $contrasena = "";
        $conn = new PDO("mysql:host=localhost;dbname=vetingweb1", $usuario, $contrasena);
        $ban = true;
        //$usr="es@gmail.com";
        // set the PDO error mode to exception
        $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        $field_values_array = $_POST['field_name'];
        $hours_values_array = $_POST['field_hour'];
        foreach (array_combine($field_values_array, $hours_values_array) as $serv => $hora) {
            $sql="INSERT INTO proveedores(correo, servicio, horario) VALUES('".$_SESSION['username']."','".$serv."','".$hora."')";
            $gsent = $conn->prepare($sql);
            $gsent->execute();
        }
        $realizado=1;
        $sql="UPDATE perfiles set realizado='".$realizado."' where correo='".$_SESSION['username']."'";
        $gsent = $conn->prepare($sql);
        $gsent->execute();
    }catch(PDOException $e){
        print "¡Error!: " . $e->getMessage() . "<br/>";
        die();
    }
    $conn = null;
?>