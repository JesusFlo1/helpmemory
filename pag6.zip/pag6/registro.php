<?php
     try {
        //session_start();
        $usuario = "root";
        $contrasena = "";
        $correo=$_POST['usuario_ctrl'];
        $pass=$_POST['pass_ctrl'];
        $nom=$_POST['nom_ctrl'];
        $ap=$_POST['ap_ctrl'];
        $tipo=$_POST['tipo_ctrl'];
        if($tipo==-1){
            $ban_prov=-1;
        }
        $conn = new PDO("mysql:host=localhost;dbname=vetingweb1", $usuario, $contrasena);
        $ban = true;
        // set the PDO error mode to exception
        $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        //echo "HOLA!";
        $sql="SELECT * FROM users WHERE correo ='".$correo."'";
        $gsent = $conn->prepare($sql);
        $gsent->execute();
        //echo "HOLA!";
        if($result3 = $gsent->fetch(PDO::FETCH_OBJ)){
            $ban = false;
            
        }

        if ($ban){
            $sql = "INSERT INTO users (correo, contrasena, nombre, apellidos, tipo)
        
            VALUES ('".$correo."', '".$pass."', '".$nom."', '".$ap."', '".$ban_prov."')";
            // use exec() because no results are returned
            
            $conn->exec($sql);
            //administrar solicitudes
            if($tipo==-1){
                $sol_aprobada=0;
                $ban_atendido=$sol_aprobada;
                $sql_sol="INSERT INTO solicitudes (correo, solicitud_atendida, solicitud_aprobada)
            VALUES ('".$correo."', '".$ban_atendido."', '".$sol_aprobada."')";
            $conn->exec($sql_sol);
                $sql_per="INSERT INTO perfiles (correo, realizado) VALUES ('".$correo."', '".$sol_aprobada."')";
                $conn->exec($sql_per);
            //$gsent = $conn->prepare($sql_sol);
            //$gsent->execute();
            }
            
            
            echo "<script> alert('Registrado correctamente');  window.location= 'index.php'</script>";
        }else{
            echo "<script> alert('Usuario duplicado. Utilice otro usuario para registrarse'); window.location= 'registro.php'</script>";

        }
        }
    catch(PDOException $e)
    {
        print "¡Error!: " . $e->getMessage() . "<br/>";
    die();
    }
    $conn = null;
?>