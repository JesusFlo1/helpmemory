<?php
$correo = $_POST['correo'];
$serv = $_POST['servicio'];
$horas = $_POST['horario'];
echo "datos recibidos: " . $correo ."<br>";
echo "datos recibidos: " . $serv ."<br>";
echo "datos recibidos: " . $horas ."<br>";



try{

    $conn = new PDO('mysql:host=localhost;dbname=vetingweb1', "root", "");
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    if($correo != "" OR $serv != "" OR $horas != ""){
        $consulta1 = "INSERT INTO proveedores(correo,servicio,horario) Values ('$correo' ,'$serv','$horas')";
        $conn->exec($consulta1);        
    }else
        echo "no llenaste datos";

   
}catch(PDOException $e){
    echo "ERROR: " . $e->getMessage();
}
//header("Location: proveedores.php");
?>