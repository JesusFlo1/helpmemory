<?php
    session_start();
    try{
        $usuario = "root";
        $contrasena = "";
        $conn = new PDO("mysql:host=localhost;dbname=vetingweb", $usuario, $contrasena);
        $ban = true;
        // set the PDO error mode to exception
        $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        //echo "HOLA!";
        
        //$conn = new PDO("mysql:host=localhost;dbname=vetingweb", $usuario, $contrasena);
        //$ban = true;
        //$correo=$_POST['fileselect'];
        // set the PDO error mode to exception
        /*
        $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        $smt = $conn->prepare('SELECT correo from solicitudes WHERE solicitud_atendida=0');
        $smt->execute();
        $data = $smt->fetchAll();
        */
        $field_values_array = $_POST['field_name'];
        $hours_values_array = $_POST['field_hour'];
        //print_r($field_values_array);
        //print_r($hours_values_array);
        foreach (array_combine($field_values_array, $hours_values_array) as $serv => $hora) {
            echo $serv;
            echo $hora;
        }
        /*
        foreach($field_values_array as $serv){
            //$sql="SELECT * FROM users WHERE correo ='".$correo."'";
            $sql="INSERT INTO proveedores(correo, servicio, horario) VALUES('".$_SESSION['username']."','".$serv."','".."')";
            $gsent = $conn->prepare($sql);
            $gsent->execute();
        }
        */

    }catch(PDOException $e){
        print "¡Error!: " . $e->getMessage() . "<br/>";
        die();
    }
    $conn = null;
?>