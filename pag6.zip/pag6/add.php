<?php
$dia = $_POST['fecha'];
$asunto = $_POST['asunto'];
$correo = $_POST['correo'];
//$mes = $_POST['mes'];
//$year = $_POST['year'];
//$hora = $_POST['hora'];
$hora = $_POST['appt'];
echo "datos recibidos: " . $hora ."<br>";
echo "datos recibidos: " . $asunto ."<br>";
echo "datos recibidos: " . $dia ."<br>";
echo "datos recibidos: " . $correo ."<br>";

try{

    $conn = new PDO('mysql:host=localhost;dbname=vetingweb1', "root", "");
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    if($dia != "" OR $asunto != "" OR $hora != ""){
        $consulta1 = "INSERT INTO agenda(dia,hora,asunto,correo) Values ('$dia' ,'$hora','$asunto','$correo')";
        $conn->exec($consulta1);        
    }else
        echo "no llenaste datos";

   
}catch(PDOException $e){
    echo "ERROR: " . $e->getMessage();
}
header("Location: usuarios.php");
?>