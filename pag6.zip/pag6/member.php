<?php
    session_start();
    if (isset($_SESSION['loggedin']) && $_SESSION['loggedin'] == true) {
        echo "Welcome to the member's area, " . $_SESSION['username'] . "!";
        echo $_SESSION["tipo"];
        include "solicitudes.php";
        echo "<a href='salir.php'>Salir</a>";
    } else {
        echo "Please log in first to see this page.";
    }
?>