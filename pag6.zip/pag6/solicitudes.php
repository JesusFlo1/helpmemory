<!DOCTYPE html>
    <header>
        <title>Solicitudes de proveedores</title>
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
        <link rel="stylesheet" href="assets/css/main.css" />

    </header>
    
    <body>
            <div class="table-wrapper">
            <?php include 'crearTabla.php';?>
            </div>
            <!--later on-->
            <form action="gestionSolicitudes.php" method="post">
                <div class="form-group" >
                    <select name="select_solicitudes" id="select_solicitudes">
                    <?php
                        try{
                            $usuario = "root";
                            $contrasena = "";
                            $conn = new PDO("mysql:host=localhost;dbname=vetingweb1", $usuario, $contrasena);
                            $ban = true;
                            //$correo=$_POST['fileselect'];
                            // set the PDO error mode to exception
                            $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
                            $smt = $conn->prepare('SELECT correo from solicitudes WHERE solicitud_atendida=0');
                            //SELECT users.correo, users.nombre, users.apellidos from users, solicitudes where users.correo=solicitudes.correo and solicitud_atendida=0;
                            $smt->execute();
                            $data = $smt->fetchAll();
                            //echo correo;
                            /*
                            $sql="SELECT * FROM users WHERE correo ='".$correo."'";
                            $gsent = $conn->prepare($sql);
                            $gsent->execute();
                            */
                        }catch(PDOException $e){
                            print "¡Error!: " . $e->getMessage() . "<br/>";
                            die();
                        }
                        $conn = null;
                    ?>
                    <?php foreach ($data as $row): ?>
                        <option><?=$row["correo"]?></option>
                    <?php endforeach ?>
                    </select>
                </div>
                <div class="form-group">
                    <div class="form-check">
                    <input type="radio" id="acept-sol" class="form-check-input" name="solicitud_ctrl"  value=0 required="required">
                        <label class="form-check-label" for="acept-sol">
                        Rechazar solicitud
                        </label>
                    </div>
                </div>

                <div class="form-group">
                    <div class="form-check">
                    <input type="radio" id="rej-sol" class="form-check-input" name="solicitud_ctrl"  value=1>
                        <label class="form-check-label" for="rej-sol">
                            Aceptar solicitud   
                        </label>
                    </div>
                </div>

                <input type="submit" class="btn btn-primary" value="Enviar cambios" id="boton">     
            </form>
    </body>
</html>