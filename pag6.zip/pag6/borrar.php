<?php
$id = $_POST['id'];
echo $id;
$pdo = new PDO('mysql:host=localhost;dbname=vetingweb1', "root", "");
$sql = "DELETE FROM agenda WHERE id =  '$id'";
$stmt = $pdo->prepare($sql);
$stmt->bindParam($id, $id, PDO::PARAM_INT);   
$stmt->execute();
header("Location: usuarios.php");
?>