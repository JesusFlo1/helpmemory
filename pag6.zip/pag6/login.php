<?php
 //session_start();
try {
    $usuario = "root";
    $contrasena = "";
    $mbd = new PDO('mysql:host=localhost;dbname=vetingweb1', $usuario, $contrasena);
    $band=false;
    $not_accepted=false;
    $usr =  $_POST['username'];
    $passwor =  $_POST['password'];
    $sql="SELECT * FROM users WHERE correo ='".$usr."' and contrasena = '".$passwor."' ";
    $gsent = $mbd->prepare($sql);
    $gsent->execute();
    //$_SESSION['nombre'] =  $nom = "nombre";
    //print("PDO::FETCH_OBJ: ");
    //print("Devolver la siguiente fila como un objeto anónimo con nombres de columna como propiedades\n");
    //$result3 = $gsent->fetch(PDO::FETCH_OBJ);
    if($result3 = $gsent->fetch(PDO::FETCH_OBJ)){
        if($result3->tipo==-1){
            $sql_sol="SELECT solicitud_aprobada, solicitud_atendida from solicitudes WHERE correo='".$usr."'";
            $gsent = $mbd->prepare($sql_sol);
            $gsent->execute();
            if($result4 = $gsent->fetch(PDO::FETCH_OBJ)){
                if($result4->solicitud_atendida==0){
                    echo "<script> alert('Su solicitud no ha sido atendida aún. Vuelva después');  window.location= 'index.php'</script>";
                }else{
                    if($result4->solicitud_aprobada==0){
                        echo "<script> alert('Lo lamentamos, pero su solicitud fue rechazada.');  window.location= 'index.php'</script>";
                    }
                }
            }
        }else{
            session_start();
            $_SESSION['loggedin'] = true;
            $_SESSION['username'] = $usr;
            $_SESSION['tipo'] = $result3->tipo;
            //Para ver si tienen perfil
            if($result3->tipo==1){
                
                $sql_profile="SELECT realizado from perfiles WHERE correo='".$usr."'";
                $gsent = $mbd->prepare($sql_profile);
                $gsent->execute();
                if($result5 = $gsent->fetch(PDO::FETCH_OBJ)){
                    if($result5->realizado==0){
                        //echo "<script> alert('xd'); ";
                        echo "<script> alert('Su solicitud fue aceptada. Procederá a crear su perfil de proveedor');  window.location= 'crearPerfilProveedor.php'</script>";
                    }
                }
                
            }
            $band=true;
        }
        /*
        session_start();
        $_SESSION['loggedin'] = true;
        $_SESSION['username'] = $usr;
        $_SESSION['tipo'] = $result3->tipo;
        $band=true;
        */
        echo "<span>Usuario encontrado</span>";
    }
    else{
        echo "Usuario no encontrado";
    }
    
    if ($band){
        echo "<script> window.location= 'index.php'</script>";
    }else{
        echo "<p>Usuario o contraseña erronea</p>";
        echo "<script> window.location= 'login.html'</script>";
    }
    
    $mbd = null;
    
} catch (PDOException $e) {
    print "¡Error!: " . $e->getMessage() . "<br/>";
    die();
}
?>