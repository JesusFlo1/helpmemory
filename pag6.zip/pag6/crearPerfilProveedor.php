<html lang="es-MX">  
      <head>  
           <title>Agregue sus servicios</title>  
           <meta charset="utf-8">
           <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.0/jquery.min.js"></script>  
           <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css" />  
           <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>  
           <!---->
           <link rel="stylesheet" href="//jonthornton.github.io/jquery-timepicker/jquery.timepicker.css">

            <script src="//code.jquery.com/jquery-1.10.2.js"></script>
            <script src="//code.jquery.com/ui/1.11.3/jquery-ui.js"></script>

            <!-- Updated JavaScript url -->
            <script src="//jonthornton.github.io/jquery-timepicker/jquery.timepicker.js"></script>

      </head>  
      <body>  
           <div class="container">  
                <br />  
                <br />  
                <h2 class="text-center">Agregue los servicios que ofrece</h2>  
                <div class="form-group">  
                     <form name="add_name" id="add_name">  
                          <div class="table-responsive">  
                               <table class="table table-bordered" id="dynamic_field">  
                                    <tr>  
                                         <td><input type="text" name="field_name[]" placeholder="Servicio" class="form-control name_list" required="required" /></td>  
                                         <td><input type="text" class="timepicker form-control" name="field_hour[]" required="required"/></td>
                                         <td><button type="button" name="add" id="add" class="btn btn-success">Agregar más</button></td>  
                                    </tr>  
                               </table>  
                               <input type="button" name="submit" id="submit" class="btn btn-info" value="Guardar" />  
                          </div>  
                     </form>  
                </div>  
           </div>  
      </body>  
 </html>  
 <script>  
 $(document).ready(function(){  
      var i=1;  
      $('#add').click(function(){  
           i++;  
           $('#dynamic_field').append('<tr id="row'+i+'"><td><input type="text" name="field_name[]" placeholder="Servicio" class="form-control name_list required="required"" /></td><td><input type="text" class="timepicker form-control" name="field_hour[]" required="required"/></td><td><button type="button" name="remove" id="'+i+'" class="btn btn-danger btn_remove">X</button></td></tr>');  
           $(document).ready(function(){
        $('.timepicker').timepicker({
            timeFormat: 'H:i:s',
            step: 60,
            minTime: '9',
            maxTime: '5:00pm',
            defaultTime: '11',
            startTime: '9:00',
            dynamic: false,
            dropdown: true,
            scrollbar: true,
        });
    });
      });  
      $(document).on('click', '.btn_remove', function(){  
           var button_id = $(this).attr("id");   
           $('#row'+button_id+'').remove();  
      });  
      $('#submit').click(function(){            
           $.ajax({  
                url:"crearPerfil.php",  
                method:"POST",  
                data:$('#add_name').serialize(),  
                success:function(data)  
                {  
                     alert(data);  
                     $('#add_name')[0].reset();  
                }  
           });  
      });  
 });  
 </script>
 <script type="text/javascript">
    $(document).ready(function(){
        $('.timepicker').timepicker({
            timeFormat: 'H:i:s',
            step: 60,
            minTime: '9',
            maxTime: '5:00pm',
            defaultTime: '11',
            startTime: '9:00',
            dynamic: false,
            dropdown: true,
            scrollbar: true,
        });
    });
</script>
   