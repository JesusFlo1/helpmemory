<?php
    try{
        $usuario = "root";
        $contrasena = "";
        $conn = new PDO("mysql:host=localhost;dbname=vetingweb1", $usuario, $contrasena);
        $ban = true;
        $correo=$_POST['select_solicitudes'];
        $aprobacion=$_POST['solicitud_ctrl'];
        // set the PDO error mode to exception
        $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        //echo $correo;
        
        $sql="UPDATE solicitudes SET solicitud_atendida=1, solicitud_aprobada='".$aprobacion."' WHERE correo ='".$correo."'";
        $gsent = $conn->prepare($sql);
        $gsent->execute();
        //
        if($aprobacion==1){
            $sql="UPDATE users SET tipo='".$aprobacion."' WHERE correo ='".$correo."'";
            $gsent = $conn->prepare($sql);
            $gsent->execute();
        }
        echo "<script> alert('Cambios realizados correctamente');  window.location= 'solicitudes.php'</script>";
    }catch(PDOException $e){
        print "¡Error!: " . $e->getMessage() . "<br/>";
        die();
    }
    $conn = null;
?>